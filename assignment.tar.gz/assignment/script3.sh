# !/bin/bash

for f in x*; 
do
	mv -- "$f" "${f}_new"
	echo $(date) "$f --> ${f}_new" >> assignment.log
done
